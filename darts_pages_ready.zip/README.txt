GitHub Pages 公開手順
1. GitHubで新規Publicリポジトリを作成
2. index.htmlをリポジトリの最上位にアップロード
3. Settings → Pages → Build and deployment → Deploy from a branch → main / (root) → Save
4. 表示されたURLをSafariで開く
5. Safariの共有メニューから「ホーム画面に追加」

注意: このHTMLは公開されます。
